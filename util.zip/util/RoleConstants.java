package kosta.mvc.util;

public interface RoleConstants {
   public static final String ROLE_USER="ROLE_USER";
   String ROLE_ADMIN="ROLE_ADMIN";
   
}
